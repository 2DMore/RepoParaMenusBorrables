/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;

/**
 * FXML Controller class
 *
 * @author donco
 */
public class MenuController implements Initializable {
    
    
    @FXML
    private BorderPane bp;
    
    @FXML
    private Button butP1;

    @FXML
    private Button butP2;

    @FXML
    private Button butP3;

    

    @FXML
    void changeP1(ActionEvent event) {
        loadPage("Screen1");
    }

    @FXML
    void changeP2(ActionEvent event) {
        loadPage("");
    }

    @FXML
    void changeP3(ActionEvent event) {
        loadPage("");
    }

    



    /**
     * Initializes the controller class.
     */
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    private void loadPage(String page){
        Parent root = null;
        
        try {
            root = FXMLLoader.load(getClass().getResource("/Interfaces/"+page+".fxml"));
        } catch (IOException ex) {
            Logger.getLogger(MenuController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        bp.setCenter(root);
        
    }
}
